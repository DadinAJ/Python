from parent_Hewan import binatang

class Ayam(binatang):
    def __init__(self, nama, makanan, hidup, berkembang_biak):
        super( ).__init__( nama, makanan, hidup, berkembang_biak)