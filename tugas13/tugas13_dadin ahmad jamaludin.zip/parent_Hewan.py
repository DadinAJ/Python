class binatang:
    def __init__(self, nama, makanan, hidup, berkembang_biak) :
        self.nama = nama
        self.makanan = makanan
        self.hidup = hidup
        self.berkembang_biak = berkembang_biak